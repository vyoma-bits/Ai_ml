# Devkings---DeepHack-submission
our submission for EightFold.ai Hackathon
